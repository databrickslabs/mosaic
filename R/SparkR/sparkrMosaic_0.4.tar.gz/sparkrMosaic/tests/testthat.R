library(testthat)
library(SparkR)
library(sparkrMosaic)
test_check("sparkrMosaic")
