-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Product-native spatial SQL
-- MAGIC
-- MAGIC > Databricks has 80+ Spatial SQL expressions under development + GEOMETRY / GEOGRAPHY types, currently in private preview. This is a quick demo of some of those functions using a small [strava](https://www.strava.com/) dataset.
-- MAGIC
-- MAGIC __Notes:__
-- MAGIC
-- MAGIC * Requires that you are enrolled in the private preview(s) to execute and running on DBR 16.4+ with Photon.
-- MAGIC * This example is configured to run on Serverless-GC (General Compute) or Classic Compute. 
-- MAGIC   * During the types private preview (starting with DBR 16.4), customers need to convert type to interchange formats in order to render, e.g. `SELECT * EXCEPT(geom), ST_AsText(geom) as wkt FROM <tbl>`. This will be addressed with DBR 17.1 (public preview) as types will automatically render as WKT. This applies on Serverless-GC or SQL Warehouses primarily.
-- MAGIC
-- MAGIC ---
-- MAGIC __Original Author:__ Stuart Lynn | __Maintainer:__ Michael Johns | _Last Updated:_ June 04, 2025

-- COMMAND ----------

-- MAGIC %python
-- MAGIC %pip install "numpy <2.0,>=1.23.5"
-- MAGIC %pip install geopandas folium mapclassify --quiet

-- COMMAND ----------

-- MAGIC %python
-- MAGIC import os
-- MAGIC import geopandas as gpd
-- MAGIC import pyspark.databricks.sql.functions as DBF
-- MAGIC import pyspark.sql.functions as F

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## What `ST_` functions are available?

-- COMMAND ----------

SHOW FUNCTIONS LIKE 'ST_*'

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## What is the definition of a given `ST_` function?

-- COMMAND ----------

DESCRIBE FUNCTION EXTENDED st_buffer

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Construct a geometry
-- MAGIC
-- MAGIC > In the preview (as of DBR 16.4), GEOMETRY / GEOGRAPHY types are not displayed, so we can convert to WKT when rendering. This will be handled by product in the future.

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW pois AS
WITH park AS (
  SELECT
    "POINT (-0.000767 51.477798)" AS wkt
)
SELECT
  "General Wolfe" AS poi_name,
  ST_GEOMFROMTEXT(wkt, 4326) AS geom,
  wkt
FROM
  park;

SELECT
  * EXCEPT(geom)
FROM
  pois;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC See also:
-- MAGIC - st_geomfromgeojson
-- MAGIC - st_geomfromwkb
-- MAGIC - st_makeline
-- MAGIC - st_makepolygon
-- MAGIC - st_point

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Quick inspection of our data

-- COMMAND ----------

-- MAGIC %python
-- MAGIC _tbl = spark.table("pois").drop("geom")
-- MAGIC gs = gpd.GeoSeries.from_wkt(_tbl.toPandas()["wkt"], crs=4326)
-- MAGIC pdf = _tbl.toPandas()
-- MAGIC pdf["geometry"] = gs
-- MAGIC gdf = gpd.GeoDataFrame(pdf, geometry="geometry")
-- MAGIC gdf.explore()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Coordinate reprojection
-- MAGIC
-- MAGIC > Starting from British National Grid [2700], will reproject to WGS84 [4326].

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW areas AS
WITH bng_poly AS (
  SELECT
    "Polygon ((539080.74751770845614374 177832.91306236910168082, 538767.14163828617893159 177684.27982682932633907, 538727.31745586439501494 177673.18859504663851112, 538621.84594145440496504 177616.95230604690732434, 538490.54813365358859301 177526.66315907711395994, 538461.83612446254119277 177475.85392566624796018, 538466.63019655959215015 177422.62076200800947845, 538477.19970560283400118 177402.8968720713746734, 538515.22874738450627774 177357.2380391139886342, 538559.66927617788314819 177321.75953704561106861, 538577.28611368732526898 177288.88596884300932288, 538600.60744349961169064 177169.44750937586650252, 538625.09037635033018887 177130.08916657301597297, 538648.84648620593361557 177117.39449425134807825, 538700.42835317435674369 177065.43241473636589944, 538749.9418425892945379 176966.71622413786826655, 538798.00173944456037134 176921.32852166821248829, 538822.66879277874249965 176875.30273452715482563, 538902.44626043341122568 176770.73795371776213869, 538981.31591152853798121 176699.5043591340072453, 539001.45930460619274527 176696.71848380187293515, 539100.53612874797545373 176742.78883285738993436, 539180.19766917137894779 176764.98013099154923111, 539311.5966025177622214 176851.966067130852025, 539377.52282120834570378 176887.12700300174765289, 539480.11801618535537273 176926.62874431553063914, 539529.15005440777167678 176967.99971074820496142, 539575.38804935966618359 176989.28076505078934133, 539581.70609962672460824 177002.79634332819841802, 539647.44598334014881402 177044.62610658182529733, 539653.76379332377109677 177058.14164582575904205, 539649.6901807285612449 177084.71425135689787567, 539624.83299735363107175 177137.40057581866858527, 539555.43555313709657639 177228.89047401363495737, 539520.28041602007579058 177291.29953734739683568, 539471.85091075743548572 177350.00893362716306001, 539458.30143866187427193 177356.30838098999811336, 539392.25132515386212617 177447.88782484497642145, 539289.26398220960982144 177545.12575660482980311, 539223.31043143896386027 177633.37107035593362525, 539178.77629905252251774 177672.17467219801619649, 539140.10464662709273398 177741.15433048742124811, 539123.03277574293315411 177754.02790662919869646, 539074.24719945201650262 177826.0654000723734498, 539080.74751770845614374 177832.91306236910168082))" AS wkt_27700
)
SELECT
  "Greenwich Park" AS area_name,
  ST_GEOMFROMTEXT(wkt_27700, 27700) AS geom_27700,
  ST_GEOMFROMTEXT(wkt_4326, 4326) AS geom_4326,
  wkt_27700,
  wkt_4326
FROM
  (
    SELECT
      wkt_27700,
      ST_ASTEXT(ST_TRANSFORM(ST_SETSRID(ST_GEOMFROMTEXT(wkt_27700), 27700), 4326)) AS wkt_4326
    FROM
      bng_poly
  );

SELECT
  * EXCEPT(geom_27700, geom_4326)
FROM
  areas;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC _tbl = spark.table("areas").drop("geom_27700", "geom_4326")
-- MAGIC gs = gpd.GeoSeries.from_wkt(_tbl.toPandas()["wkt_4326"], crs=4326)
-- MAGIC pdf = _tbl.toPandas()
-- MAGIC pdf["geometry"] = gs
-- MAGIC gdf = gpd.GeoDataFrame(pdf, geometry="geometry")
-- MAGIC gdf.explore()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Compute spatial measures

-- COMMAND ----------

SELECT 
  area_name,
  ST_AREA(geom_27700) AS geom_area_m, --cartesian area, metres
  ST_AREA(geom_4326) AS geom_area_deg, --cartesian area, degrees
  ST_GEOGAREA(wkt_4326) AS geog_area_m --geodesic area (assumes WGS84)
FROM
  areas

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Point-in-poly join
-- MAGIC
-- MAGIC > This is using the built-in join support for spatial types. 
-- MAGIC
-- MAGIC __Note:__ This is an ongoing area of improvement. The example below shows use of BROADCAST hint to enhance performance. You can use `EXPLAIN EXTENDED` to check the query plan.

-- COMMAND ----------

SELECT
  /*+ BROADCAST(p) */
  a.area_name,
  p.poi_name,
  ST_INTERSECTS(a.geom_4326, p.geom) AS intersects
FROM areas a , pois p

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Apply an index to the data
-- MAGIC
-- MAGIC > In more scaled uses, you would persist the table instead of making it a temporary view. 
-- MAGIC
-- MAGIC __Note:__ H3 remains a great pattern for scaled indexing (among other benefits), but want to highlight that Databricks is [WIP] on OOTB spatial join performance without requiring H3.

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW indexed_poi AS
SELECT
  *,
  H3_POINTASH3(wkt, 9) AS h3
FROM pois;

SELECT * EXCEPT(geom) FROM indexed_poi;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC indexed_point_pdf = (
-- MAGIC   spark.table("indexed_poi")
-- MAGIC   .drop("geom")
-- MAGIC   .withColumn("h3_geom", DBF.h3_boundaryaswkt("h3"))
-- MAGIC   ).toPandas()
-- MAGIC indexed_point_pdf["geometry"] = gpd.GeoSeries.from_wkt(indexed_point_pdf["wkt"], crs=4326)
-- MAGIC indexed_point_pdf["h3_geometry"] = gpd.GeoSeries.from_wkt(indexed_point_pdf["h3_geom"], crs=4326)
-- MAGIC m = gpd.GeoDataFrame(indexed_point_pdf, geometry="geometry").explore(zoom_start=16)
-- MAGIC gpd.GeoDataFrame(indexed_point_pdf, geometry="h3_geometry").explore(m=m)

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW h3_tessellation AS
  SELECT
    *,
    EXPLODE(H3_TESSELLATEASWKB(wkt_4326, 9)) AS h3
  FROM areas;
SELECT format_number(COUNT(1),0) as count from h3_tessellation;

-- COMMAND ----------

SELECT * EXCEPT(geom_27700, geom_4326) FROM h3_tessellation LIMIT 1;

-- COMMAND ----------

CREATE OR REPLACE TEMPORARY VIEW indexed_areas AS
SELECT
  * EXCEPT (h3),
  h3.*,
  ST_ASTEXT(ST_GEOMFROMWKB(h3.chip)) AS chip_wkt
FROM h3_tessellation;

SELECT format_number(COUNT(1),0) as count FROM indexed_areas;

-- COMMAND ----------

SELECT * EXCEPT(geom_27700, geom_4326) FROM indexed_areas LIMIT 1;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC indexed_areas_pdf = (
-- MAGIC   spark.table("indexed_areas").select("wkt_4326", "chip_wkt")
-- MAGIC   ).toPandas()
-- MAGIC indexed_areas_pdf["h3_geometry"] = gpd.GeoSeries.from_wkt(indexed_areas_pdf["chip_wkt"], crs=4326)
-- MAGIC gpd.GeoDataFrame(indexed_areas_pdf, geometry="h3_geometry").explore()

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Indexed join
-- MAGIC
-- MAGIC > Make use of the H3 cellids to avoid cross-joins. 
-- MAGIC
-- MAGIC __Note:__ Databricks is implementing OOTB spatial performance to auto-handle indexing; meanwhile, customers still need to reason about it.

-- COMMAND ----------

SELECT
  a.area_name,
  p.poi_name
FROM indexed_areas a
  INNER JOIN indexed_poi p
  ON a.cellid = p.h3
WHERE
  a.core OR ST_INTERSECTS(ST_GEOMFROMWKB(a.chip, 4326), p.geom)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Doing something useful: how much time do people spend in the park?
-- MAGIC
-- MAGIC > We'll analyse a couple of Strava activities and determine how long this person spends enjoying the view over the river on their runs. __Note:__ Serverless doesn't yet allow access to Workspace files, so copying to Volumes.

-- COMMAND ----------

-- MAGIC %python
-- MAGIC # update to your preferred location
-- MAGIC # - you have to pre-generate the volumes path
-- MAGIC data_path = "/Volumes/geospatial_docs/strava/data"
-- MAGIC os.environ["DATA_PATH"] = data_path

-- COMMAND ----------

-- MAGIC %sh 
-- MAGIC cp -n ./strava/*.csv $DATA_PATH
-- MAGIC ls -lh $DATA_PATH

-- COMMAND ----------

-- MAGIC %python
-- MAGIC (
-- MAGIC   spark.read
-- MAGIC   .csv(data_path, header=True, inferSchema=True)
-- MAGIC   .withColumnRenamed("track_se_1", "track_seg_point_id")
-- MAGIC   .select(
-- MAGIC     F.expr("st_geomfromtext(wkt, 4326) as geom_4326"),
-- MAGIC     "WKT", "track_seg_point_id", "ele", "time"
-- MAGIC   )
-- MAGIC   .where("!st_isempty(WKT)")
-- MAGIC   .withColumn("user", F.lit("uuʎ˥ ʇɹɐnʇS"))
-- MAGIC   .withColumn("time", F.to_timestamp("time", "yyyy/MM/dd HH:mm:ss.SSS"))
-- MAGIC   .withColumn("date", F.date_trunc("day", "time"))
-- MAGIC   .withColumn("h3", DBF.h3_pointash3("WKT", 9))
-- MAGIC   ).createOrReplaceTempView("run_track")
-- MAGIC
-- MAGIC print(f"count? {spark.table('run_track').count():,}")
-- MAGIC spark.table("run_track").drop("geom_4326").limit(3).display()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC run_track_pdf = spark.table("run_track").drop("geom_4326").sample(fraction=0.5).toPandas()
-- MAGIC gs = gpd.GeoSeries.from_wkt(run_track_pdf["WKT"], crs=4326)
-- MAGIC run_track_pdf["geometry"] = gs
-- MAGIC gdf = gpd.GeoDataFrame(run_track_pdf, geometry="geometry")
-- MAGIC gdf.explore(column="date")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC run_track_pdf = (
-- MAGIC   spark.table("run_track")
-- MAGIC   .withColumn("h3_geom", DBF.h3_boundaryaswkt("h3"))
-- MAGIC   .select("h3", "h3_geom", "date")
-- MAGIC   .distinct()
-- MAGIC   ).toPandas()
-- MAGIC gs = gpd.GeoSeries.from_wkt(run_track_pdf["h3_geom"], crs=4326)
-- MAGIC run_track_pdf["geometry"] = gs
-- MAGIC gdf = gpd.GeoDataFrame(run_track_pdf, geometry="geometry")
-- MAGIC gdf.explore(column="date")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC events_in_aoi_df = (
-- MAGIC   spark.table("run_track").alias("t")
-- MAGIC   .join(
-- MAGIC     other=spark.table("indexed_areas").alias("a"),
-- MAGIC     on=F.col("t.h3")==F.col("a.cellid"),
-- MAGIC     how="inner"
-- MAGIC     )
-- MAGIC   .where(
-- MAGIC     F.col("a.core") | 
-- MAGIC     F.expr("""
-- MAGIC       st_intersects(
-- MAGIC         st_geomfromwkb(a.chip, 4326), 
-- MAGIC         t.geom_4326
-- MAGIC       )
-- MAGIC     """)
-- MAGIC   )
-- MAGIC   .select("user", "date", "time", "track_seg_point_id", "ele", "WKT")
-- MAGIC )
-- MAGIC print(f"count? {events_in_aoi_df.count():,}")
-- MAGIC events_in_aoi_df.limit(3).display()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC events_pdf = events_in_aoi_df.toPandas()
-- MAGIC gs = gpd.GeoSeries.from_wkt(events_pdf["WKT"], crs=4326)
-- MAGIC events_pdf["geometry"] = gs
-- MAGIC gdf = gpd.GeoDataFrame(events_pdf, geometry="geometry")
-- MAGIC gdf.explore(column="date")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC (
-- MAGIC     events_in_aoi_df.groupBy("user", "date")
-- MAGIC     .agg(F.min("time").alias("in_time"), F.max("time").alias("out_time"))
-- MAGIC     .withColumn(
-- MAGIC         "dwell",
-- MAGIC         #F.timestamp_diff(start=F.col("in_time"), end=F.col("out_time"), unit="SECOND") # <- Spark 4.0+
-- MAGIC         F.col("out_time").cast("long") - F.col("in_time").cast("long")                  # <- Spark 3.x
-- MAGIC     )
-- MAGIC ).display()